# Mahdi System — بناء APK من الهاتف

هذا المشروع مجهز للبناء عبر GitHub Actions بدون Android Studio.

## الطريقة
1. أنشئ Repository جديد في GitHub.
2. ارفع محتويات هذا المجلد إلى الـRepository.
3. افتح تبويب **Actions**.
4. اختر **Build Mahdi System APK** ثم **Run workflow**.
5. بعد نجاح البناء، افتح الـRun ثم نزّل Artifact باسم **MahdiSystem-debug-apk**.
6. فك الضغط وستجد ملف APK للتثبيت على الهاتف.

Firebase config موجود مسبقاً في `app/google-services.json`.
