package com.mahdisystem.app

import android.os.Bundle
import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

private const val REQUESTS = "repair_requests"
private const val SHOP_PHONE = "0542933109"
private val Blue = Color(0xFF1687FF)
private val Bg = Color(0xFF070B12)
private val CardBg = Color(0xFF111824)
private const val CHANNEL_ID = "mahdi_system_alerts"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createNotificationChannel()
        if (android.os.Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1001)
        setContent { MahdiSystemApp() }
    }

    private fun createNotificationChannel() {
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL_ID, "تنبيهات Mahdi System", NotificationManager.IMPORTANCE_HIGH)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
}

fun sendAlert(context: Context, title: String, text: String) {
    if (android.os.Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
    val notification = NotificationCompat.Builder(context, CHANNEL_ID)
        .setSmallIcon(com.mahdisystem.app.R.drawable.logo)
        .setContentTitle(title).setContentText(text).setPriority(NotificationCompat.PRIORITY_HIGH)
        .setAutoCancel(true).build()
    ContextCompat.getSystemService(context, NotificationManager::class.java)?.notify((System.currentTimeMillis() % Int.MAX_VALUE).toInt(), notification)
}

data class RepairRequest(val id:String="", val ownerId:String="", val customerName:String="", val customerPhone:String="", val device:String="", val problem:String="", val delivery:Boolean=false, val address:String="", val status:String="جديد", val createdAt:Long=0L)

class RepairRepository {
    private val auth=FirebaseAuth.getInstance(); private val db=FirebaseFirestore.getInstance()
    suspend fun uid():String { auth.currentUser?.let{return it.uid}; return auth.signInAnonymously().await().user!!.uid }
    suspend fun submit(name:String,phone:String,device:String,problem:String,delivery:Boolean,address:String):String { val ref=db.collection(REQUESTS).document(); ref.set(mapOf("ownerId" to uid(),"customerName" to name,"customerPhone" to phone,"device" to device,"problem" to problem,"delivery" to delivery,"address" to address,"status" to "جديد","createdAt" to System.currentTimeMillis())).await(); return ref.id }
    suspend fun mine():List<RepairRequest> { val s=db.collection(REQUESTS).whereEqualTo("ownerId",uid()).orderBy("createdAt",Query.Direction.DESCENDING).get().await(); return s.documents.map{it.toR()} }
    suspend fun all():List<RepairRequest> { val s=db.collection(REQUESTS).orderBy("createdAt",Query.Direction.DESCENDING).get().await(); return s.documents.map{it.toR()} }
    suspend fun login(e:String,p:String)=auth.signInWithEmailAndPassword(e.trim(),p).await()
    suspend fun status(id:String,s:String)=db.collection(REQUESTS).document(id).update("status",s).await()
    fun listenAll(onChange: (List<RepairRequest>, Boolean) -> Unit): com.google.firebase.firestore.ListenerRegistration {
        var first = true
        return db.collection(REQUESTS).orderBy("createdAt",Query.Direction.DESCENDING).addSnapshotListener { snap, _ ->
            if (snap == null) return@addSnapshotListener
            val list = snap.documents.map{it.toR()}
            val newRequest = !first && snap.documentChanges.any { it.type == com.google.firebase.firestore.DocumentChange.Type.ADDED }
            first = false
            onChange(list, newRequest)
        }
    }
    fun listenMine(onChange: (List<RepairRequest>, List<RepairRequest>) -> Unit): com.google.firebase.firestore.ListenerRegistration {
        var first = true
        var previous = emptyMap<String,String>()
        return db.collection(REQUESTS).whereEqualTo("ownerId", auth.currentUser?.uid ?: "").orderBy("createdAt",Query.Direction.DESCENDING).addSnapshotListener { snap, _ ->
            if (snap == null) return@addSnapshotListener
            val list = snap.documents.map{it.toR()}
            val changed = if (first) emptyList() else list.filter { previous[it.id] != null && previous[it.id] != it.status }
            previous = list.associate { it.id to it.status }
            first = false
            onChange(list, changed)
        }
    }
    fun logout()=auth.signOut()
    private fun com.google.firebase.firestore.DocumentSnapshot.toR()=RepairRequest(id, getString("ownerId")?:"",getString("customerName")?:"",getString("customerPhone")?:"",getString("device")?:"",getString("problem")?:"",getBoolean("delivery")?:false,getString("address")?:"",getString("status")?:"جديد",getLong("createdAt")?:0L)
}

@Composable fun AppTheme(content:@Composable()->Unit){ MaterialTheme(colorScheme=darkColorScheme(primary=Blue,background=Bg,surface=CardBg),content=content) }

@Composable fun MahdiSystemApp(){
    var screen by remember{mutableStateOf("splash")}; var requests by remember{mutableStateOf<List<RepairRequest>>(emptyList())}; var msg by remember{mutableStateOf<String?>(null)}; val repo=remember{RepairRepository()}; val scope=rememberCoroutineScope()
    AppTheme { Surface(Modifier.fillMaxSize(),color=Bg){ CompositionLocalProvider(LocalLayoutDirection provides androidx.compose.ui.unit.LayoutDirection.Rtl){
        when(screen){
            "splash"->SplashScreen{screen="home"}
            "home"->HomeScreen({screen="request"},{scope.launch{runCatching{requests=repo.mine()};screen="track"}},{screen="login"})
            "request"->RequestScreen({screen="home"}){n,p,d,pr,del,a->scope.launch{try{repo.submit(n,p,d,pr,del,a);requests=repo.mine();msg="تم إرسال الطلب بنجاح ✓";screen="track"}catch(e:Exception){msg="تعذر إرسال الطلب، تحقق من الإنترنت"}}}}
            "track"->TrackScreen(requests,msg,{scope.launch{runCatching{requests=repo.mine()}}},{screen="home"})
            "login"->LoginScreen({screen="home"},{e,p->scope.launch{try{repo.login(e,p);requests=repo.all();msg=null;screen="admin"}catch(_:Exception){msg="البريد أو كلمة المرور غير صحيحة"}}},msg)
            "admin"->AdminScreen(requests,{repo.logout();screen="home"},{scope.launch{runCatching{requests=repo.all()}}}){id,s->scope.launch{try{repo.status(id,s);requests=repo.all()}catch(_:Exception){msg="تعذر تحديث الحالة"}}}
        }
    }}}
}


@Composable fun SplashScreen(onDone:()->Unit){
    LaunchedEffect(Unit){ kotlinx.coroutines.delay(1800); onDone() }
    Box(Modifier.fillMaxSize().background(Color.Black), contentAlignment=Alignment.Center){
        Column(horizontalAlignment=Alignment.CenterHorizontally){
            Icon(painterResource(com.mahdisystem.app.R.drawable.logo),contentDescription="Mahdi System",modifier=Modifier.size(250.dp),tint=Color.Unspecified)
            Spacer(Modifier.height(18.dp))
            Text("MAHDI SYSTEM",color=Color.White,fontSize=24.sp,fontWeight=FontWeight.ExtraBold)
            Text("PHONE REPAIR & SHOP",color=Blue,fontSize=12.sp,fontWeight=FontWeight.Bold)
        }
    }
}

@Composable fun Header(title:String,subtitle:String?=null,onBack:(()->Unit)?=null){ Row(Modifier.fillMaxWidth().padding(18.dp),verticalAlignment=Alignment.CenterVertically){ if(onBack!=null){TextButton(onClick=onBack){Text("رجوع")};Spacer(Modifier.width(4.dp))}; Column{Text(title,fontSize=25.sp,fontWeight=FontWeight.Bold);subtitle?.let{Text(it,color=Color.LightGray,fontSize=13.sp)}};Spacer(Modifier.weight(1f)) } }
@Composable fun HomeScreen(onRequest:()->Unit,onTrack:()->Unit,onAdmin:()->Unit){ Column(Modifier.fillMaxSize().padding(20.dp),horizontalAlignment=Alignment.CenterHorizontally){Spacer(Modifier.height(22.dp));Icon(painterResource(com.mahdisystem.app.R.drawable.logo),"",Modifier.size(125.dp),tint=Color.Unspecified);Text("MAHDI SYSTEM",fontSize=29.sp,fontWeight=FontWeight.ExtraBold);Text("خدمة صيانة أجهزتك بسهولة",color=Color.LightGray); Text("للتواصل: $SHOP_PHONE",color=Blue,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=6.dp));Spacer(Modifier.height(30.dp));ActionCard("🔧","طلب صيانة","أرسل لنا عطل جهازك الآن",onRequest);ActionCard("📋","متابعة طلباتي","شاهد حالة طلبات الصيانة",onTrack);Spacer(Modifier.height(8.dp));TextButton(onClick=onAdmin){Text("دخول لوحة التحكم")}} }
@Composable fun ActionCard(icon:String,title:String,desc:String,onClick:()->Unit){Card(onClick=onClick,modifier=Modifier.fillMaxWidth().padding(vertical=6.dp),shape=RoundedCornerShape(18.dp)){Row(Modifier.padding(18.dp),verticalAlignment=Alignment.CenterVertically){Text(icon,fontSize=30.sp);Spacer(Modifier.width(15.dp));Column{Text(title,fontSize=19.sp,fontWeight=FontWeight.Bold);Text(desc,color=Color.LightGray,fontSize=13.sp)}}}}

@Composable fun RequestScreen(onBack:()->Unit,onSubmit:(String,String,String,String,Boolean,String)->Unit){var n by remember{mutableStateOf("")};var p by remember{mutableStateOf("")};var d by remember{mutableStateOf("هاتف")};var pr by remember{mutableStateOf("")};var del by remember{mutableStateOf(false)};var a by remember{mutableStateOf("")};Column(Modifier.fillMaxSize()){Header("طلب صيانة جديد","أدخل معلومات الجهاز والعطل",onBack); Text("للاستفسار: $SHOP_PHONE",color=Blue,fontWeight=FontWeight.Bold,modifier=Modifier.padding(horizontal=18.dp));LazyColumn(contentPadding=PaddingValues(horizontal=18.dp,vertical=4.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){item{Field("الاسم",n){n=it}};item{Field("رقم الهاتف",p){p=it}};item{Text("نوع الجهاز",fontWeight=FontWeight.Bold);Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){listOf("هاتف","حاسوب","تلفاز").forEach{FilterChip(d==it,{d=it},{Text(it)})}}};item{Field("وصف العطل",pr,{pr=it},5)};item{Row(verticalAlignment=Alignment.CenterVertically){Checkbox(del,{del=it});Text("أحتاج خدمة التوصيل")}};if(del)item{Field("عنوان التوصيل",a){a=it}};item{Button(onClick={onSubmit(n,p,d,pr,del,a)},enabled=n.isNotBlank()&&p.isNotBlank()&&pr.isNotBlank()&&(!del||a.isNotBlank()),modifier=Modifier.fillMaxWidth().height(55.dp),shape=RoundedCornerShape(15.dp)){Text("إرسال الطلب",fontSize=17.sp)}};item{Spacer(Modifier.height(30.dp))}}}}
@Composable fun Field(label:String,value:String,onChange:(String)->Unit,lines:Int=1){OutlinedTextField(value,onChange,Modifier.fillMaxWidth().then(if(lines>1)Modifier.height(125.dp)else Modifier),label={Text(label)},minLines=lines,shape=RoundedCornerShape(14.dp))}

@Composable fun TrackScreen(rs:List<RepairRequest>,msg:String?,refresh:()->Unit,back:()->Unit){ val context=androidx.compose.ui.platform.LocalContext.current; val repo=remember{RepairRepository()}; var live by remember{mutableStateOf(rs)}; LaunchedEffect(Unit){ try{repo.uid(); val reg=repo.listenMine{list,changed->live=list; changed.forEach{sendAlert(context,"تحديث طلب الصيانة","طلب #${it.id.takeLast(8)}: ${it.status}")}}; awaitDispose{reg.remove()} }catch(_:Exception){} }; Column(Modifier.fillMaxSize()){Header("متابعة طلباتي","آخر حالة لطلباتك",back);msg?.let{Text(it,color=Color(0xFF65E6A1),modifier=Modifier.padding(horizontal=18.dp))};Row(Modifier.fillMaxWidth().padding(horizontal=18.dp)){Text("${live.size} طلب");Spacer(Modifier.weight(1f));TextButton(onClick=refresh){Text("تحديث")}};LazyColumn(Modifier.padding(horizontal=18.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){items(live){RequestCard(it,false,{})}}}}
@Composable fun RequestCard(r:RepairRequest,admin:Boolean,onStatus:(String)->Unit){Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(16.dp)){Column(Modifier.padding(16.dp)){Text("طلب #${r.id.takeLast(8)}",fontWeight=FontWeight.Bold);if(admin)Text("${r.customerName} • ${r.customerPhone}",color=Color.LightGray);Text("${r.device} — ${r.problem}",modifier=Modifier.padding(vertical=6.dp));Text("الحالة: ${r.status}",color=Blue);if(r.delivery)Text("🚚 ${r.address}",color=Color.LightGray);if(admin){Row{listOf("جديد","مقبول","قيد التصليح","جاهز","تم التسليم").filter{it!=r.status}.forEach{s->TextButton(onClick={onStatus(s)}){Text(s,fontSize=11.sp)}}}}}}}

@Composable fun LoginScreen(back:()->Unit,login:(String,String)->Unit,error:String?){var e by remember{mutableStateOf("")};var p by remember{mutableStateOf("")};Column(Modifier.fillMaxSize().padding(20.dp)){Header("لوحة التحكم","دخول صاحب المحل",back);Spacer(Modifier.height(15.dp));Field("البريد الإلكتروني",e){e=it};Spacer(Modifier.height(10.dp));OutlinedTextField(p,{p=it},Modifier.fillMaxWidth(),label={Text("كلمة المرور")},visualTransformation=PasswordVisualTransformation(),shape=RoundedCornerShape(14.dp));error?.let{Text(it,color=MaterialTheme.colorScheme.error,modifier=Modifier.padding(top=10.dp))};Spacer(Modifier.height(18.dp));Button(onClick={login(e,p)},enabled=e.isNotBlank()&&p.isNotBlank(),modifier=Modifier.fillMaxWidth().height(55.dp),shape=RoundedCornerShape(15.dp)){Text("دخول لوحة التحكم")}}}

@Composable fun AdminScreen(rs:List<RepairRequest>,logout:()->Unit,refresh:()->Unit,onStatus:(String,String)->Unit){ val context=androidx.compose.ui.platform.LocalContext.current; val repo=remember{RepairRepository()}; var live by remember{mutableStateOf(rs)}; LaunchedEffect(Unit){ val reg=repo.listenAll{list,newRequest->live=list; if(newRequest) sendAlert(context,"طلب صيانة جديد","تم استقبال طلب جديد من زبون")}; awaitDispose{reg.remove()} }; Column(Modifier.fillMaxSize()){Row(Modifier.fillMaxWidth().padding(12.dp),verticalAlignment=Alignment.CenterVertically){Text("لوحة Mahdi System",fontSize=24.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.weight(1f));TextButton(onClick=refresh){Text("تحديث")};TextButton(onClick=logout){Text("خروج")}};Row(Modifier.padding(horizontal=16.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)){Stat("الكل",live.size);Stat("الجديد",live.count{it.status=="جديد"});Stat("جاهز",live.count{it.status=="جاهز"})};Spacer(Modifier.height(10.dp));LazyColumn(Modifier.padding(horizontal=16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){items(live){RequestCard(it,true){s->onStatus(it.id,s)}}}}}
@Composable fun Stat(t:String,n:Int){Card(Modifier.weight(1f),shape=RoundedCornerShape(14.dp)){Column(Modifier.padding(12.dp)){Text(t,color=Color.LightGray,fontSize=12.sp);Text("$n",fontSize=23.sp,fontWeight=FontWeight.Bold)}}}
